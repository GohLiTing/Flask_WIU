from flask_wtf import FlaskForm
from wtforms import SelectField, RadioField, SubmitField, Form
from wtforms.validators import DataRequired

class UserEntryForm(FlaskForm):  # Fixed import
    vision = SelectField('Eyesight:', [DataRequired()], choices=[('', 'Select'), ('Sees poorly', 'Sees poorly'), ('Sees moderately', 'Sees moderately'), ('Sees well', 'Sees well')], default='')
    audition = SelectField('Hearing:', [DataRequired()], choices=[('', 'Select'), ('Hears moderately', 'Hears moderately'), ('Hears well', 'Hears well')], default='')
    
    # ...
    gait_speed_slower = RadioField('Gait_speed_slower:', [DataRequired()], choices=[('Yes', 'Yes'), ('No', 'No')], default='')
    # ...

    grip_strength_abnormal = RadioField('Grip_strength_abnormal:', [DataRequired()], choices=[('Yes', 'Yes'), ('No', 'No')], default='')
    low_physical_activity = RadioField('Low_physical_activity:', [DataRequired()], choices=[('Yes', 'Yes'), ('No', 'No')], default='')
    predict = SubmitField('Predict')

